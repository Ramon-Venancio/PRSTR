jogador = {} 
A = []
B = []
a_carteira = 0
b_carteira = 0